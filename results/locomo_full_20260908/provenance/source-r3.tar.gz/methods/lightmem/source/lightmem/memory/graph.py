class GraphMem:
    pass
