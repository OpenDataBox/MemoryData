# Manuscript verification - 2026-09-03

This audit concerns the written artifact, not the scientific performance of MTM.

| Requirement | Verified evidence |
|---|---|
| Independent framework-based manuscript | New title, abstract, seven main sections, typed-memory algorithm, and implementation contracts; no excluded prior-method name or dependency in the manuscript |
| Both supplied illustrations used | Two unchanged image copies; SHA-256 matches for each original and copy; rendered on PDF pages 13 and 14 |
| Existing Related Work incorporated | All 38 original citation keys retained; original bibliography copied byte-for-byte |
| References resolve | 44 bibliography entries and 44 cited keys; zero missing keys and zero duplicate keys; final PDF contains no unresolved `??` markers |
| Prior-work limitations are explicit | Introduction, closest-overlap paragraph, and limitations distinguish relational binding, stale derived knowledge, and ungrounded feedback; existing systems' overlapping capabilities are acknowledged |
| Concise experiments | Exactly three descriptive experimental subsections; no numbered R1/R2/RQ experiment labels; Memory-R1 appears only as a cited prior paper |
| LoCoMo example grounded | Local official `conv-26`: D7:11 on July 12, 2023; D17:10 on October 13, 2023; Becoming Nicole answer; both evidence IDs; official category 1 |
| No evaluation-label feedback | Explicit evaluator-only warning in the example section and original-figure caption; frozen snapshot protocol for official QA |
| No fabricated findings | Abstract, experimental section, limitations, appendix, and page header identify the empirical status as pending; no measured superiority is claimed |
| Official formatting | ICLR 2027 style and bibliography style match downloaded official files; working-copy title overrides do not modify the style files |
| Main-text length | Conclusion ends on page 8; full PDF has 14 pages including references, implementation appendix, and two landscape figures |
| Compilation | Tectonic completed with exit code 0; no unresolved citations, no overfull boxes, and no replacement characters in extracted PDF text |
| Visual QA | All 14 initial rendered pages inspected. After the final content revision, unchanged pages were confirmed pixel-identical by PNG hashes; changed pages 6, 7, and 12 were inspected again. No clipping, overlap, or unreadable figure placement found |

The TeX toolchain emitted non-fatal underfull-box warnings, a package-comment UTF-8 warning, and duplicate destination warnings for float anchors. These did not produce missing glyphs or visible layout defects. Final review covered the rendered artifact, not just the compiler's exit status.

Not completed or claimed: integrated MTM implementation, learned-procedure evaluation, official-baseline execution, benchmark measurements, controlled-update results, or an acceptance prediction. These are future research work; the requested new manuscript and compact experimental design are the completed deliverables.
